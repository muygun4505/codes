package newpackage;

import java.util.Objects;

public class MainClass {
    public static void main(String[] args) {
        Rastgele R1 = new Rastgele(20);
        Rastgele R2 = new Rastgele(20);
        System.out.println("BİRBİRİNE EŞİTLER Mİ? : "+R1.equals(R2));
        System.out.println();
        System.out.println("ŞİMDİ DE HASHCODELARINA BAKALIM");
        System.out.println("R1 Hashcode : "+R1.hashCode()+" R2 Hashcode : "+R2.hashCode());


    }
    static class Rastgele {
        int yas;

        public Rastgele(int yas) {
            this.yas = yas;
        }
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Rastgele rastgele)) return false;
            return yas == rastgele.yas;
        }
        @Override
        public int hashCode() {
            return Objects.hash(yas);
        }
    }
}
