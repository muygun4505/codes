package newpackage;
public class Konular {
    public static void main(String[] args) {
        // Acaba iki değer eşit mi? True değer döndürür mü?
        String isim = new String("Muhammet");
        String abc = "Muhammet";
        System.out.println(isim==abc);
        // false döndürdü. Çünkü üstteki heap alanında bir nesne, alttaki ise String pool'dan bir değer.
        // Eşitliği şöyle sorgulayabiliriz:
        System.out.println(isim.equals(abc)); // True döndürdü.
        System.out.println("---------------------------------------------");
        // String pool'dan iki değeri karşılaştırabiliriz.
        String abc2 ="abc";
        String def="abc";
        System.out.println(abc2 == def);
        //Bu ise true döndürür çünkü ikisi de birer String Pool değişkenidir, nesne değildir.
        System.out.println("---------------------------------------------");
        String abc3 ="muhammet"; // dedikten sonra alt satırlarda;
        abc3 = "muhamemt uyğun";
        /* yazarsak eğer bu abc3 değişkeni heap alanında artık muhammet yazılı kutucuğu değil,
         muhammet uyğun yazılı kutucuğu tutacaktır. */
        System.out.println(abc3); // muhammet uyğun yazdırıldı.
        System.out.println("---------------------------------------------");
        // Stringler değiştirilemez. Bundan dolayı her bir muhammet için ayrı bir kutucuk açılmaz. Örneğin:
        String abc4 = "muhammet";
        String def2 = "muhammet";
        String ghj2 = "muhammet";
        String klm2 = "muhammet";
        /* Bunların hepsi de heap alanındaki TEK BİR ORTAK KUTUCUĞU referans alır.
        Yani hepsi için ayrı ayrı tek tek "muhammet" kutucukları oluşturulmaz.
        1 tane "muhammet" kutucuğu oluşturulur ve hepsi aynı kutucuğu gösterir.
        Dikkat edilmesi gereken bir diğer nokta da şu: eğer alt satırlarda abc4 değişkeni için yeni bir
        string yazı yazarsak diğerleri değişmez. Örneğin; */
        abc4 = "muhammet uyğun"; /* yazarsak eğer,
        üstteki String abc4 = "muhammet"; ifadesindeki abc4 değişkeni artık "muhammet" kutucuğunu tutmayacak.
        "muhammet uyğun" diye yeni bir kutu açılacak ve orayı tutacak abc4 değişkeni.
        Diğerleri ise "muhammet" kutucuğunu tutmaya devam edecektir. */
        System.out.println("---------------------------------------------");
         // CONCAT KULLANIMI: Var olan string yazıya başka kelimeler eklemeye yarar. Örneğin:
        String abc5 = "muhammet"; // yazdıktan sonra altına
        String yeni = abc5.concat(" uyğun"); // yazarsak ve yeni ismini yazdırırsak:
        System.out.println(yeni); // sonuç olarak muhammet uyğun diye çıktı görürüz
        System.out.println("---------------------------------------------");
        /* String isim3= new String("muhammet"); bu ifade heap alanında bir nesnedir.
        Bu ifadeyi String pool'a taşırsak alttaki abc6 değişkeniyle kıyaslama yapabiliriz.
        String pool'a taşımak için sonuna intern() ekliyoruz. Örneğin: */
        String isim3= new String("muhammet").intern();
        String abc6 = "muhammet";
        System.out.println(isim3 == abc6); // true değer döndürür.
    }
}












