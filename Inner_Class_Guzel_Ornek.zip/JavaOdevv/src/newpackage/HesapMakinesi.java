package newpackage;
public class HesapMakinesi {

    private class Toplama {
        public int topla(int i, int j) {
            return i + j;
        }
    }

    public int topla(int i, int j) { // Bu metot ile main metodunda kullanıcı hesaplama yapacak.
        HesapMakinesi hm = new HesapMakinesi();
        HesapMakinesi.Toplama toplayici = hm.new Toplama();
        int toplam = toplayici.topla(i, j);
        // topla metodunu toplayici nesnesiyle birleştirip çalıştırdık.
        return toplam;

    }

    private class Cikarma {
        public int cikar(int i, int j) {
            return i - j;
        }
    }

    public int cikar(int i, int j) { // Bu metot ile main metodunda kullanıcı hesaplama yapacak.
        HesapMakinesi hm = new HesapMakinesi();
        HesapMakinesi.Cikarma cikartici = hm.new Cikarma();
        int cikan = cikartici.cikar(i, j);
        return cikan;

    }

    private class Carpma {
        public int carp(int i, int j) {
            return i * j;
        }
    }

    public int carp(int i, int j) { // Bu metot ile main metodunda kullanıcı hesaplama yapacak.
        HesapMakinesi hm = new HesapMakinesi();
        HesapMakinesi.Carpma carpici = hm.new Carpma();
        int carpim = carpici.carp(i, j);
        return carpim;
    }

    private class Bolme {
        public String bolme(int i, int j) {
            if (j == 0) {
                System.out.println("Bölen sıfıra eşit olamaz");
                return "";
            } else {
                int sonuc = i / j;
                return String.valueOf(sonuc);
            }
        }
    }

    public String bol(int i, int j) {
        HesapMakinesi hm = new HesapMakinesi();
        HesapMakinesi.Bolme bolucu = hm.new Bolme();
        String bolen = bolucu.bolme(i,j);
        return bolen;
    }
}

