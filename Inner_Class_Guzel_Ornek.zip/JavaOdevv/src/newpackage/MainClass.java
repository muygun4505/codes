package newpackage;
public class MainClass {
    public static void main(String[] args) {
    HesapMakinesi hm = new HesapMakinesi();
    int carpim = hm.carp(10,5);
        System.out.println(carpim);
    int toplam = hm.topla(20,30);
        System.out.println(toplam);
    int cikan = hm.cikar(87,62);
        System.out.println(cikan);
    String bolen = hm.bol(85,15);
        System.out.println(bolen);


    }
}

