import java.util.Scanner;

public class YeniClass {
    public static void main(String[] args) {

        Scanner tara = new Scanner(System.in);
        System.out.println("RASTGELE BİR SAYI SEÇİNİZ!");
        int rastgeleSayi = (int) (Math.random() * 101);
        int kullaniciThamini = -1; /*Kullanıcı tahminini -1'e eşşitledim ve böylece sonsuz döngü oluşturup
        yanlış bilse bile kullanıcılar, tekrardan konsola sayı girebilecekler. */

        while (rastgeleSayi != kullaniciThamini) {

            kullaniciThamini = tara.nextInt();


            if (kullaniciThamini == rastgeleSayi) {
                System.out.println("DOĞRU BİLDİNİZ!");
            } else if (kullaniciThamini > rastgeleSayi) {
                System.out.println("SAYIYI AZALTIN");
            } else {
                System.out.println("SAYIYI ARTTIRIN");
            }


        }


    }
}



