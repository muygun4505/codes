import java.util.Scanner;

public class Deneme {
    public static void main(String[] args) {
        System.out.println("VÜCUT KİTLE İNDEKSİ HESAPLAYICIYA HOŞ GELDİNİZ!");

        System.out.println("LÜTFEN KİLONUZU KG CİNSİNDEN GİRİNİZ");
        Scanner tara1 = new Scanner(System.in);
        double kilo = tara1.nextDouble();
        System.out.println("Kilo : " + kilo);

        System.out.println("LÜTFEN BOYUNUZU CM CİNSİNDEN GİRİNİZ");
        Scanner tara2 = new Scanner(System.in);
        int boy = tara2.nextInt();
        System.out.println("Boy : " + boy);

        double boy2 = (double) boy / 100;

        double vucutKitleIndeksi = (kilo / (Math.pow(boy2,2)));
        System.out.println("Vücut Kitle İndeksi : " +vucutKitleIndeksi);

        if (vucutKitleIndeksi<15){
            System.out.println("Çok Ciddi Derecede Düşük kilolu");
        } else if (vucutKitleIndeksi>15 && vucutKitleIndeksi<16) {
            System.out.println("Ciddi Derecede Düşük Kilolu");
        } else if (vucutKitleIndeksi>16 && vucutKitleIndeksi<18.5){
            System.out.println("Düşük Kilolu");
        } else if (vucutKitleIndeksi>18.5 && vucutKitleIndeksi<25){
            System.out.println("Normal Kilolu");
        } else if (vucutKitleIndeksi>25 && vucutKitleIndeksi<30){
            System.out.println("Fazla Kilolu");
        } else if (vucutKitleIndeksi>30 && vucutKitleIndeksi<35){
            System.out.println("1. Derecede Hafif Obez");
        } else if (vucutKitleIndeksi>35 && vucutKitleIndeksi<40){
            System.out.println("2. Dereceden Ciddi Obez");
        } else if (vucutKitleIndeksi>40){
            System.out.println("3. Dereceden Çok Cİddi Obez");
        }
    }
}
