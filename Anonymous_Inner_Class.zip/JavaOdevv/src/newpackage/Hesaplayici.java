package newpackage;
public class Hesaplayici { // Üst class
    public void topla(int i, int j){ // Metot oluşturduk.
        System.out.println("Sonuç : "+(i+j));
    }
}
interface Ogrenci { // Interface oluşturduk.
    void dersCalis(); // Metot
}
abstract class Veliler{ // Abstract class oluşturduk.
    public void veliBilgileriniYaz(){ // Metot
        System.out.println("Öğrenci veli bilgileri burada.");
    }
}






