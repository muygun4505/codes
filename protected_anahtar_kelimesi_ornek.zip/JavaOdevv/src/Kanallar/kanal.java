package Kanallar;
import newpackage.Konular;
public class kanal extends Konular {
    @Override
    protected void denedim() {
        super.denedim();
    }
}
