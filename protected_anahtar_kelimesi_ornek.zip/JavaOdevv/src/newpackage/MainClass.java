package newpackage;
public class MainClass {
public static void main(String[] args) {
        Baba bb = new Baba();
        bb.anadil();
        AA aa = new AA();
        aa.boy = 10;
        aa.el = "Çift ellll";
    System.out.println(aa.el);
    System.out.println();
    System.out.println(aa.boy);
}
}

class AA extends Baba {
    @Override
    protected void anadil() {
        super.anadil();
    }
}

