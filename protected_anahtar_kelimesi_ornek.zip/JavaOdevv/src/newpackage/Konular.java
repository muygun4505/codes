package newpackage;
public class Konular{
    protected void denedim(){ // Kanallar paketinde kanal sınıfında kullanmak için yazdım.
    }
    public static void main(String[] args) {
    Cocuk Ahmet = new Cocuk();
    Ahmet.boy=180;
    Ahmet.anadil();
    Baba baba = new Baba();
    baba.boy=120;
    System.out.println(baba.el);

    }
}
class Baba {
    protected int boy;
    public String el="çift";
    protected void anadil(){
        System.out.println("Türkçe");
    }

}
class Cocuk extends Baba{
    @Override
    protected void anadil() {
        System.out.println("Bilingual");
    }
}
/* protected anahtar kelimesiyle oluşturulmuş bir değişken ya da metodu, SADECE ya mevcut paketteki
protected değişken veya metot oluşturulmuş sınıfı, extends etmiş sınıflarda kullanabiliriz
ya da FARKLI PAKET ALTINDAKİ extends edilmiş (kalıtılmış) ve buna ek import edilmiş sınıflarda
kullanabiliriz. Bunun haricinde, kullanamayız. */

// BİRİNCİ KULLANIM ŞEKLİ
/*  Örneğin (Aynı paket altında olmak koşuluyla)
A class'ında protected ile oluşturulmuş metot ya da değişken varsa class B extends A diyerek,
A'daki protected ile oluşturulmuş şeyleri B class'ında kullanabiliriz. Ayrıca main metodunda A classından
ya da B classından nesne üreterek de bu protected ifadeler kullanılabilir.*/

// İKİNCİ KULLANIM ŞEKLİ
/* Birinci adım: public class oluşturup bu class'ta protected ile değişken ya da metot tanımladığımızı
varsayalım:
package ilk_paket;
public class OrnekClass {
protected void ornekMetot(){
    }
}
İkinci adım: Başka bir paketteki classa gidelim. Sonra OrnekClass'ı extends (kalıtım) edelim:
package ikinci_paket;
public class OrnekClass2 extends OrnekClass{
NOT: OrnekClass kırmızı renkte olacak ALT + ENTER yap ve import class yap
NOT2: Artık burada sağ tık > Generate diyip ornekMetot override edilebilir.
  }
 */
