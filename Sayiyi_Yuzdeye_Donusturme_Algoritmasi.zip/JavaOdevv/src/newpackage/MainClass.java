package newpackage;
import java.util.Scanner;
public class MainClass {
    public static void main(String[] args) {
        Denemem a = new Denemem();
        a.hesapla();

    }
}
         class Denemem {
           public void hesapla() {
                Scanner tara2 = new Scanner(System.in);

                System.out.println("Toplam iş ilanı adedi nedir? (Örnek: 1000)");
                int A = tara2.nextInt();
                if (A > 0) { // İlk koşul

                    System.out.println("Kaç farklı iş pozisyonu buldunuz? (Örnek: 4 )");
                    Scanner tara1 = new Scanner(System.in);
                    int isIlanSayisi = tara1.nextInt();
                    if (isIlanSayisi < A && isIlanSayisi > 0) { // İkinci Koşul
                        int[] ilan = new int[isIlanSayisi];

                        System.out.println("Her bir iş pozisyonunda toplam kaç ilan var? (Örnek: 20)");

                        for (int i = 0; i < ilan.length; i++) {
                            double sonn = 0;

                            int rastgele = tara1.nextInt();
                            if (sonn <= A && rastgele < A) {
                                ilan[i] = rastgele;  // iş ilan sayısı kadar toplam ilan adedi olmalı
                                double gecici = ilan[i];
                                double sonuc = (gecici / A) * 100;
                                String sonDeger = String.format("%.01f", sonuc);
                                sonn = sonn + gecici;
                                System.out.println("Yüzdelik olarak denk geldiği değer: %" + sonDeger);
                            } else {
                                System.out.println("YANLIŞ BİR DEĞER GİRDİNİZ!!");
                                break;
                            }
                        }
                    }
                } else {
                    System.out.println("DEĞERLERİ YANLIŞŞŞ GİRDİNİZ");
                }
            }
}