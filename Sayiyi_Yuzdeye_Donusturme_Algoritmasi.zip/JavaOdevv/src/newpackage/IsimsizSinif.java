package newpackage;
public class IsimsizSinif {
    public static void main(String[] args) {
        Hesaplayici h = new Hesaplayici() { // Üst sınıf nesnesi oluşturuldu
            public void topla(int i, int j) { // topla metodu, sağ tık > Generate ile override edildi.
                System.out.println("İki sayının toplamı hesaplandı."); // Override dan sonra yazdık bunu.
                super.topla(i, j);
            }
        }; // Buraya noktalı virgül koymazsak hata verir.
        h.topla(10, 5); // Üst sınıf nesnesi ile topla metodunu birlikte kullandık.
        System.out.println("---------------------------------------------------------------");
        Ogrenci ogr1 = new Ogrenci() { // Bunu yazarken, editor otomatik olarak override etti.
            public void dersCalis() { // Interface override edildi.
                System.out.println("Ogrenci interface'i new ile oluşturuldu");
            }
        }; // Buraya noktalı virgül koymazsak hata verir.
        ogr1.dersCalis(); // Ogrenci nesnesi ile interface metodunu birlikte kullandık.
        System.out.println("---------------------------------------------------------------");
        Veliler v = new Veliler() { // Bu kısmı yazarken, editör alttaki metodu override etti.
            public void veliBilgileriniYaz() { // Abstract classtaki metot, override edildi.
                super.veliBilgileriniYaz();
            }
        }; // Buraya noktalı virgül koymazsak hata verir.
        v.veliBilgileriniYaz(); // Veliler ensnesiyle abstract class metodunu birlikte kullandık.
    }
}
/* Özetle: Bir metodu, sanki bir class içindeymiş gibi (buna anonim/isimsiz class diyoruz.) override ettik.
  Bunun mantığını şöyle düşün: Hesaplayici isimli class üst classtır, topla metodu ise Hesaplayici sınıfının
  bir alt sınıfında (anonim/isimsiz) bir classın içinde. İşte bu anonim (aslında böyle bir class yok ama var
  kabul ediyoruz) sınıfı ve Hesaplayici adındaki üst sınıfı birlikte kullanıp nesne ürettik ve topla metoduna
  ulaştık.

  Ayrıca normalde interface ve abstract classlardan new ile nesne üretilemezdi.
  Ancak anonim sınıf mantığıyla interface ve abstract classtan da nesne üretip bunların
  metotlarını gerçekleştirdik.
  */













