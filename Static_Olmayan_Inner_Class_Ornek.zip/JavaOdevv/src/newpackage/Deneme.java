package newpackage;
public class Deneme {
    public static void main(String[] args) {
        Araba a = new Araba(); // a nesnesi oluşturuldu.
        Araba.Motor b = a.new Motor(); // b nesnesini a üzerinden oluşturduk.
        // Artık a ve b nesneleriyle ilgili şeyleri görüntüleyebiliriz.
        System.out.println(a.getMarka());
        System.out.println(b.getModel());
        a.modelSoyle();
        b.motoruAnlat();
    }

}
