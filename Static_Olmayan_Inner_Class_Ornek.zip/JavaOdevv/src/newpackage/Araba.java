package newpackage;
public class Araba { // Dış Sınıf
     String marka="RENAULT"; // Dış sınıf değişkeni
    public void modelSoyle(){ // Dış sınıf metodu
        System.out.println("2011 MODEL");
    }
    public String getMarka() { // Getter metot
        return marka;
    }

   public class Motor { // İç sınıf
         private String model="MERCEDES 2012 MODEL"; // İç sınıf değişkeni
        public void motoruAnlat(){ // İç sınıf metodu
            System.out.println("BU MOTOR SONRADAN TAKILDI.");
        }
        public String getModel() { // Getter metodu
            return model;
        }
       public void denemeMetot1(){
            /* Dış sınıf değişkenini (marka) burada kullanildik. Ama üst sınıfta benzer
            bir kullanım yani System.out.println(model) şeklinde bir gösterim yapamayız.
             */
           System.out.println(marka);
       }
    }

}
