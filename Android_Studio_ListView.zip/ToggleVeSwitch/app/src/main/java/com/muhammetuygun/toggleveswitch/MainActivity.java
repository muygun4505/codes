package com.muhammetuygun.toggleveswitch;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.VideoView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Calendar;
/* Palette'den ListView aldık ve tasarım ekranımıza bıraktık, zincirledik, id verdik.
ListView, ArrayList<> ve ArrayAdapter<> tanımlamalarımızı yaptık ve kodlarımızı yazdık. Böylece
liste şeklinde butonlar oldu ve her butona (listeye) basınca bir şey yaptırdık. Unutma: ListView
ve GirdView yapısı yerine yazılımcılar artık çoğunlukla RecyclerViewe'u tercih ediyor.
*/
public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayList<String> ulkeler = new ArrayList<>();
    private ArrayAdapter<String> veriAdaptoru;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    listView = findViewById(R.id.listView);
    ulkeler.add("Türkiye");
    ulkeler.add("Almanya");
    ulkeler.add("İngiltere");
    ulkeler.add("İspanya");
    ulkeler.add("Japonya");
    veriAdaptoru = new ArrayAdapter<>(MainActivity.this,
            android.R.layout.simple_list_item_1, android.R.id.text1,ulkeler);
    /* MainActivity.this => bu sınıfta olduğumuz için böyle yazdık.
     simple_list_item_1 => Java bu liste tasarımını bize otomatik önerdi.
     android.R.id.text1 => yine bunu da Java önerdi bize. Ülkeler bunun içine yazılacak.
     En sona da ulkeler veri kümesini yazdık. */
    listView.setAdapter(veriAdaptoru); // listView'un içine veri adaptörümüzü yerleştirdik.
    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(MainActivity.this, "Seçtiğiniz ülke: "+ulkeler.get(position),Toast.LENGTH_SHORT).show();
        }});}}