package newpackage;
public class NewClass {
    public static void main(String[] args) {

    Encapsulation urun = new Encapsulation();

    urun.setUrunAdi("Rastgele Ürün");
    System.out.println("Ürün adını ekrana yazdıralım :" +urun.getUrunAdi());
    }
}
