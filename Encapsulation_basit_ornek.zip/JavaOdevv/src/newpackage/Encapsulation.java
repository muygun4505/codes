package newpackage;
public class Encapsulation {

    String urunAdi;

    public String getUrunAdi() {
        return urunAdi;
    }
    public void setUrunAdi(String urunAdi){
        this.urunAdi = urunAdi;
    }
}
