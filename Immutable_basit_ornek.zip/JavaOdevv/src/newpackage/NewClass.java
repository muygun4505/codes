package newpackage;
public class NewClass {
    public static void main(String[] args) {
        Araba a1 = new Araba(160,"Renault", "Mavi");
        System.out.println("1. ARABA : "+a1.getMarka());
        System.out.println("--------------------------------------------");
        a1.arabaGoster();


    }
}
