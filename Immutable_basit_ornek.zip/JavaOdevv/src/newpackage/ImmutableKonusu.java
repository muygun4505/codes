package newpackage;
public class ImmutableKonusu {

}
 final class Araba {
     private final int maxHiz;
     private final String marka;
     private final String renk;

      public int getMaxHiz() {
           return maxHiz;
      }
      public String getMarka() {
           return marka;
      }
      public String getRenk() {
           return renk;
      }
      public Araba(int maxHiz, String marka, String renk){
          this.maxHiz = maxHiz;
          this.marka = marka;
          this.renk = renk;
     }
     public void arabaGoster(){
         System.out.println("Arabanın Markası: "+getMarka()+" En Yüksek Hızı : "+getMaxHiz()+ " Rengi :"+getRenk());
     }
 }
