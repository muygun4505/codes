package newpackage;
public class MainClass {
    public static void main(String[] args) {
        LocalInnerClass lic = new LocalInnerClass(); // Önce en üst class nesnesi oluşturduk.
        String bolum = lic.bolmeYap(15,5); // Oluşturduğumuz nesne üzerinden metoda eriştik.
        System.out.println("Sonuç : " +bolum); } }


/*  Belli bir kod bloğunun içinde yaşayıp ve o kod bloğunun içinde ölen (Yani başka metotlarda,
başka classlarda, başka yerlerde, başka kod bloğunda tekrar çalıştırılmayacak olan) sınıf türüne
local inner class denir.Bu class'ın mantığını şudur: "Kullan at"

Local Inner Classları kullanmak için nesne üretmek yeterlidir.

Bu sınıflar abstract veya final olabilir, ama aynı anda hem abstract hem final olamaz.
Local Inner Classlar erişim belirleyicisine de sahip olamaz.

Local inner sınıflar statik olamaz.Ayrıca Local Inner Classlar static değişkenlere sahip olamaz.
Ancak bir istisnası var: static final bir değişkene sahip olabilir.
Çünkü final ile belirtilen değişken sabittir, değiştirelemez. Örnek: static final int a=5;

 */









