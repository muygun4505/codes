package newpackage;
public class LocalInnerClass {
    public String bolmeYap(int sayi1, int sayi2){ // Metot
         class Bolme { // Local Inner Class
            public String bolme(int i, int j) { // Local Inner Class Metodu
                if (j == 0) {
                    System.out.println("Bölen sıfıra eşit olamaz");
                    return "";
                } else {
                    int sonuc = i / j;
                    return String.valueOf(sonuc);
                }
            }
        }
        Bolme b = new Bolme(); // Nesne oluşturmamız lazımdı, oluşturduk.
        String sonuc = b.bolme(sayi1,sayi2);
        return sonuc;
    }
}







