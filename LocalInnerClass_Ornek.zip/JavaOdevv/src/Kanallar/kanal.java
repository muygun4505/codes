package Kanallar;
public class kanal{
    public static void main(String[] args) {

    }

}
