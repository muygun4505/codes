package newpackage;

public class CemberDaire {

}   class yariCap {
    private double yariCap;
    private double alan;

    public double getAlan() {
        return alan;
    }

    public void setAlan(double yariCap) {

        yariCap = 3.14 * (yariCap * yariCap );
        this.alan = yariCap;
    }

    public double getYariCap() {
        return yariCap;
    }

    public void setYariCap(double yariCap) {
        yariCap = 2 * 3.14 * yariCap;
        this.yariCap = yariCap;
    }


    public yariCap() {
    this.yariCap = yariCap;
    }

}





