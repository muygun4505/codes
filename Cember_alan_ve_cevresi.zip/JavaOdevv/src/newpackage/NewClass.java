package newpackage;
public class NewClass {
    public static void main(String[] args) {

            yariCap c1 = new yariCap();
            yariCap c2 = new yariCap();
            c1.setYariCap(10.0); // Çevreyi oluşturduk
            System.out.println("Çemberin Çevresi : "+c1.getYariCap());
            System.out.println("----------------------------------------");
            c2.setAlan(10.0);
            System.out.println("Çemberin Alanı : "+c2.getAlan());


    }
}
